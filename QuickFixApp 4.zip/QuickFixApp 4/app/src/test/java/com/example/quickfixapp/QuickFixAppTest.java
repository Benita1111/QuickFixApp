package com.example.quickfixapp;

import static org.junit.Assert.assertEquals;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class QuickFixAppTest {
    /**
     *
     * @author benitaamaechi
     */


    public QuickFixAppTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }


    @Test
    public void testOnClick() {
        System.out.println("createLogin");
        String email = "clare444@gmail.com";
        String password = "12345678";
        QuickFixAppTest instance = new QuickFixAppTest();
        boolean expResult = true;
        boolean result = instance.testOnClick(email, password);
        assertEquals(expResult, result);
    }
}
