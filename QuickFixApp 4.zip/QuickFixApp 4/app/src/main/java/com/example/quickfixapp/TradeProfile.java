package com.example.quickfixapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class TradeProfile extends AppCompatActivity {
    TextView nameLbl,numberLbl;
    private Button logout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trade_profile);

        nameLbl = findViewById(R.id.nameLbl);
        numberLbl = findViewById(R.id.nameLbl);

        //Show date
        showAllUserData();
    }
    public void showAllUserData() {
        Intent intent = getIntent();
        String name_name = intent.getStringExtra("name");
        String number_number = intent.getStringExtra("number");

        nameLbl.setText(name_name);
        numberLbl.setText(number_number);


        logout = (Button) findViewById(R.id.logout);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(TradeProfile.this, Login.class));
            }


            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(TradeProfile.this, "Error", Toast.LENGTH_SHORT).show();
            }
        });

    }
}