package com.example.quickfixapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Register extends AppCompatActivity {
    TextInputLayout rName,rEmail,rPassword,rNumber,rOccupation,rLocation;
    Button rRegisterBtn;
    TextView rHaveAccBtn;
    FirebaseAuth fbAuth;

    FirebaseDatabase rootNode;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        rName = findViewById(R.id.name);
        rEmail = findViewById(R.id.email);
        rPassword = findViewById(R.id.password);
        rNumber = findViewById(R.id.number);
        rOccupation = findViewById(R.id.occupation);
        rLocation = findViewById(R.id.location);
        rRegisterBtn =  findViewById(R.id.RegisterBtn);
        rHaveAccBtn =  findViewById(R.id.haveAccBtn);

        fbAuth = FirebaseAuth.getInstance();
        if(fbAuth.getCurrentUser()!=null){
            startActivity(new Intent(getApplicationContext(), Login.class));
            finish();
        }

        rRegisterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = rEmail.getEditText().getText().toString().trim();
                String password = rPassword.getEditText().getText().toString().trim();

                if (TextUtils.isEmpty(email)) {
                    rEmail.setError("Please Enter Email");
                    return;
                }
                if (TextUtils.isEmpty(password)) {
                    rPassword.setError("Please Enter password");
                    return;
                }

                if (password.length() < 8) {
                    rPassword.setError("password must be >= 8 characters");
                    return;
                }
                fbAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(Register.this, "Register SuccessFully", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(), Login.class));
                        } else {
                            Toast.makeText(Register.this, "Error " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();

                        }

                    }
                });
                rootNode = FirebaseDatabase.getInstance();
                reference = rootNode.getReference("users");
                //GetVariable
                String name = rName.getEditText().getText().toString();
                String occupation =rOccupation.getEditText().getText().toString();
                String location = rLocation.getEditText().getText().toString();
                String number = rNumber.getEditText().getText().toString();

                User userClass = new User(name, occupation, location, number);
                reference.child(number).setValue(userClass);


            }
        });
                rHaveAccBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        startActivity(new Intent(getApplicationContext(), Login.class));
                    }
                });
            }
        }
