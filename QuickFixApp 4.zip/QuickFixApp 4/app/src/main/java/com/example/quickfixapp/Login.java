package com.example.quickfixapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class Login extends AppCompatActivity {
    TextInputLayout rName, rEmail, rPassword, rConfirmPassword;
    Button rLoginBtn;
    Button rBrowseBtn;
    TextView rNeedAccBtn;
    FirebaseAuth fbAuth;

@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_login);
    rEmail = findViewById(R.id.email);
    rPassword = findViewById(R.id.password);
    rConfirmPassword = findViewById(R.id.number);
    rLoginBtn = findViewById(R.id.LoginBtn);
    rNeedAccBtn = findViewById(R.id.needAccBtn);
    rBrowseBtn = findViewById(R.id.browseBtn);

    fbAuth = FirebaseAuth.getInstance();
    if(fbAuth.getCurrentUser()!=null){
        startActivity(new Intent(getApplicationContext(), TradeProfile.class));
        finish();
    }

rLoginBtn.setOnClickListener(new View.OnClickListener() {
     @Override
     public void onClick(View v) {
         String email = rEmail.getEditText().getText().toString();
         String password = rPassword.getEditText().getText().toString();

         if (TextUtils.isEmpty(email)) {
             rEmail.setError("Please Enter Email");
             return;
         }
         if (TextUtils.isEmpty(password)) {
             rPassword.setError("Please Enter password");
             return;
         }

         if (password.length() < 8) {
             rPassword.setError("password must be >= 8 characters");
             return;
         }
         fbAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
             @Override
             public void onComplete(@NonNull Task<AuthResult> task) {
                 if (task.isSuccessful()) {
                     Toast.makeText(Login.this, "Login SuccessFully", Toast.LENGTH_SHORT).show();
                     startActivity(new Intent(getApplicationContext(), TradeProfile.class));
                 } else {
                     Toast.makeText(Login.this, "Error " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();

                 }

             }
             public void isUser()
             {
              final String userEnteredName = rName.getEditText().getText().toString().trim();
              final String userEnteredPassword = rPassword.getEditText().getText().toString().trim();

              DatabaseReference reference = FirebaseDatabase.getInstance().getReference("users");
              Query checkUser = reference.orderByChild("name").equalTo(userEnteredName);

              checkUser.addListenerForSingleValueEvent(new ValueEventListener() {
                  @Override
                  public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

  if(dataSnapshot.exists()){
      rName.setError(null);
      rName.setErrorEnabled(false);

      String passwordFromDB = dataSnapshot.child(userEnteredName).child("password").getValue(String.class);
      if(passwordFromDB.equals(userEnteredPassword)){
          String nameFromDB = dataSnapshot.child("name").getValue(String.class);
          String locationFromDB = dataSnapshot.child("location").getValue(String.class);
          String occupationFromDB = dataSnapshot.child("occupation").getValue(String.class);
          String numberFromDB = dataSnapshot.child("number").getValue(String.class);

          Intent intent = new Intent (getApplicationContext(),TradeProfile.class);
          intent.putExtra("name", nameFromDB);
          intent.putExtra("location", locationFromDB);
          intent.putExtra("occupation", occupationFromDB);
          intent.putExtra("number", numberFromDB);

          startActivity(intent);
      }
      else{
          rPassword.setError("Wrong Password");
          rPassword.requestFocus();
      }

  }
  else{
      rName.setError("User Does Not Exist");
      rName.requestFocus();
  }

}
        @Override
        public void onCancelled(@NonNull DatabaseError error) {

          }
          });

         }
     });

    }
    });


        rNeedAccBtn.setOnClickListener(new View.OnClickListener() {
                                           @Override
                                           public void onClick(View view) {
                                               startActivity(new Intent(getApplicationContext(), Register.class));
                                           }
                                       });
           rBrowseBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    startActivity(new Intent(getApplicationContext(), MainActivity.class));

        }


            });
    }
}

